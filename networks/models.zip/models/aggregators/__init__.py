from .cosplace import CosPlace
from .convap import ConvAP
from .gem import GeMPool
from .mixvpr import MixVPR